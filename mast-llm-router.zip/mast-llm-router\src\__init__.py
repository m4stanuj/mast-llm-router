"""MAST LLM Router package."""

__version__ = "6.0.0"
